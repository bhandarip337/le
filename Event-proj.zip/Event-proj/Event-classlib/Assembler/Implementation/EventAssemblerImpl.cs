﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Implementation
{
    public class EventAssemblerImpl : EventAssembler
    {
        public void copy(Event events, EventDto eventDto)
        {
            events.EventId = eventDto.EventId;
            events.EventTitle = eventDto.EventTitle;
            events.EventDescription = eventDto.EventDescription;
            events.EventTime = eventDto.EventTime;
            events.EventEndTime = eventDto.EventEndTime;
            events.EventDate = eventDto.EventDate;
            events.EventEndDate = eventDto.EventEndDate;
            events.EventVenue = eventDto.EventVenue;
            events.EventImg = eventDto.EventImg;
            events.EventStatus = eventDto.EventStatus;
        }
    }
}
