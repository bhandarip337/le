﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Implementation
{
    public class NoticeAssemblerImpl : NoticeAssembler
    {
        public void copy(Notice notice, NoticeDto noticeDto)
        {
            notice.NoticeId = noticeDto.NoticeId;
            notice.NoticeTitle = noticeDto.NoticeTitle;
            notice.NoticeDescription = noticeDto.NoticeDescription;
            notice.NoticeDate = noticeDto.NoticeDate;
            notice.NoticeEndDate = noticeDto.NoticeEndDate;
            if(!string.IsNullOrWhiteSpace(noticeDto.NoticeImg))
            {
                notice.NoticeImg = noticeDto.NoticeImg;
            }
            notice.NoticeStatus = noticeDto.NoticeStatus;
        }
    }
}
