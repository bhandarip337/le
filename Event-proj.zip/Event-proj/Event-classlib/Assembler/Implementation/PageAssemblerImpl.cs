﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Implementation
{
    public class PageAssemblerImpl : PageAssembler
    {
        public void copy(Page page, PageDto pageDto)
        {
            page.PageId = pageDto.PageId;
            page.PageTitle = pageDto.PageTitle;
            page.PageDescription = pageDto.PageDescription;
            page.PageCatagory = pageDto.PageCatagory;
            page.PageImg = pageDto.PageImg;
            page.PageStatus = pageDto.PageStatus;
            page.Catagory = pageDto.Catagory;
        }
    }
}
