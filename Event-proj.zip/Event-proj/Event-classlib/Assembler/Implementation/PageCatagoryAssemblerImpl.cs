﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Implementation
{
    public class PageCatagoryAssemblerImpl : PageCatagoryAssembler
    {
        public void copy(PageCatagory pageCatagory, PageCatagoryDto pageCatagoryDto)
        {
            pageCatagory.CatagoryId = pageCatagoryDto.CatagoryId;
            pageCatagory.CatagoryName = pageCatagoryDto.CatagoryName;
            pageCatagory.CatagoryStatus = pageCatagoryDto.CatagoryStatus;
        }
    }
}
