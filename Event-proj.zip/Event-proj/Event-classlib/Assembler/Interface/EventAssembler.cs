﻿using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Interface
{
    public interface EventAssembler
    {
        void copy(Event events, EventDto eventDto);
    }
}
