﻿using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Interface
{
    public interface PageAssembler
    {
        void copy(Page page, PageDto pageDto);
    }
}
