﻿using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Assembler.Interface
{
    public interface PageCatagoryAssembler
    {
        void copy(PageCatagory pageCatagory, PageCatagoryDto pageCatagoryDto);
    }
}
