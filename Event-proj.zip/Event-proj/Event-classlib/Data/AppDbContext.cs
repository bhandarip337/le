﻿using Event_classlib.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        //Set Here
        public DbSet<PageCatagory> PageCatagory { get; set; }
        public DbSet<Page> Page { get; set; }
        public DbSet<Event> Event { get; set; }
        public DbSet<Notice> Notice { get; set; }
    }
}
