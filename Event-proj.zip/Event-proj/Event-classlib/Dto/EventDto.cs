﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Event_classlib.Dto
{
    public class EventDto
    {
        public long EventId { get; set; }
        public string EventTitle { get; set; }

        public string EventDescription { get; set; }

        public DateTime EventTime { get; set; }

        public DateTime EventEndTime { get; set; }

        public DateTime EventDate { get; set; }
        public DateTime EventEndDate { get; set; }
        public string EventVenue { get; set; }
        public string EventImg { get; set; }
        public bool EventStatus { get; set; } = true;
    }
}
