﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Event_classlib.Dto
{
    public class NoticeDto
    {
        public long NoticeId { get; set; }
        public string NoticeTitle { get; set; }

        public string NoticeDescription { get; set; }
        public DateTime NoticeDate { get; set; }
        public DateTime NoticeEndDate { get; set; }
        public string NoticeImg { get; set; }
        public bool NoticeStatus { get; set; } = true;
    }
}
