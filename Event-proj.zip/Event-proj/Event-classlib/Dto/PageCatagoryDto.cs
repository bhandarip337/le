﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Event_classlib.Dto
{
    public class PageCatagoryDto
    {
        public long CatagoryId { get; set; }
        public string CatagoryName { get; set; }
        public bool CatagoryStatus { get; set; } = true;
    }
}
