﻿using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Event_classlib.Dto
{
    public class PageDto
    {
        public long PageId { get; set; }
        public string PageTitle { get; set; }
        public string PageCatagory { get; set; }
        public string PageDescription { get; set; }
        public string PageImg { get; set; }
        public bool PageStatus { get; set; } = true;
        public virtual PageCatagory Catagory { get; set; }
    }
}
