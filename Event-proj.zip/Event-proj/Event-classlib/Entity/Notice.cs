﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Event_classlib.Entity
{
    public class Notice
    {
        [Key]
        public long NoticeId { get; set; }
        public string NoticeTitle { get; set; }
        public string NoticeDescription { get; set; }
        public DateTime NoticeDate { get; set; }
        public DateTime NoticeEndDate { get; set; }
        public string NoticeImg { get; set; }
        public bool NoticeStatus { get; set; } = true;
        public void enable()
        {
            NoticeStatus = true;
        }
        public void disable()
        {
            NoticeStatus = false;
        }

    }
}
