﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Event_classlib.Entity
{
    public class Page
    {
        [Key]
        public long PageId { get; set; }
        public string PageTitle { get; set; }
        [ForeignKey("CategoryId")]
        public string PageCatagory { get; set; }
        public string PageDescription { get; set; }
        public string PageImg { get; set; }
        public bool PageStatus { get; set; } = true;
        public void enable()
        {
            PageStatus = true;
        } 
        public void disable()
        {
            PageStatus = false;
        }
        public virtual PageCatagory Catagory { get; set; }
    }
}
