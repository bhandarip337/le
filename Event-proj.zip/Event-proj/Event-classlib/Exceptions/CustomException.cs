﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Exceptions
{
    public class CustomException : Exception
    {
        public CustomException(string message) : base(message)
        {

        }
    }
}
