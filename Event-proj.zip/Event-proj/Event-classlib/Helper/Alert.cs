﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Helper
{
    public class Alert
    {
        public string message { get; set; }
        public messageType message_type { get; set; }

    }
    public enum messageType
    {
        success,
        error
    }
}
