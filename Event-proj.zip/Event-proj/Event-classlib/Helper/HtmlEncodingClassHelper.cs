﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Helper
{
    public interface HtmlEncodingClassHelper
    {
        List<string> getAllClassNamesToBeExcluded();
    }
}
