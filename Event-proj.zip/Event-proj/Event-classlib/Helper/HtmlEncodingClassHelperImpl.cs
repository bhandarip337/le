﻿using Event_classlib.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Helper
{
    public class HtmlEncodingClassHelperImpl : HtmlEncodingClassHelper
    {
        public List<string> getAllClassNamesToBeExcluded()
        {
            return new List<string>()
            {
            };
        }
    }
}
