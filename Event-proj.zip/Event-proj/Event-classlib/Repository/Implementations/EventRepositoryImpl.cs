﻿using Event_classlib.Data;
using Event_classlib.Entity;
using Event_classlib.Helper;
using Event_classlib.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Repository.Implementations
{
    public class EventRepositoryImpl : BaseRepositoryImpl<Event>, EventRepository
    {
        public readonly AppDbContext _appDbContext;
        public EventRepositoryImpl(AppDbContext appDbContext, DetailsEncoder<Event> detailsEncoder, HtmlEncodingClassHelper htmlEncodingClassHelper) : base(appDbContext, detailsEncoder, htmlEncodingClassHelper)
        {
            _appDbContext = appDbContext;
        }
    }
}
