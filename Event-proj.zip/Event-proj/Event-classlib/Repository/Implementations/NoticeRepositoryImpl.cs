﻿using Event_classlib.Data;
using Event_classlib.Entity;
using Event_classlib.Helper;
using Event_classlib.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Repository.Implementations
{
    public class NoticeRepositoryImpl : BaseRepositoryImpl<Notice>, NoticeRepository
    {
        public readonly AppDbContext _appDbContext;
        public NoticeRepositoryImpl(AppDbContext appDbContext, DetailsEncoder<Notice> detailsEncoder, HtmlEncodingClassHelper htmlEncodingClassHelper) : base(appDbContext, detailsEncoder, htmlEncodingClassHelper)
        {
            _appDbContext = appDbContext;
        }
    }
}
