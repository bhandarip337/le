﻿using Event_classlib.Entity;
using System.Linq;

namespace Event_classlib.Repository.Interface
{
    public interface EventRepository
    {
        void insert(Event events);
        void update(Event events);
        void delete(Event events);
        Event getById(long EventId);
        IQueryable<Event> getQueryable();
    }
}
