﻿using Event_classlib.Dto;
using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Event_classlib.Repository.Interface
{
    public interface NoticeRepository
    {
        void insert(Notice notice);
        void update(Notice notice);
        void delete(Notice notice);
        Notice getById(long NoticeId);
        IQueryable<Notice> getQueryable();
    }
}
