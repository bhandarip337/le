﻿using Event_classlib.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Event_classlib.Repository.Interface
{
    public interface PageCatagoryRepository
    {
        void insert(PageCatagory pageCatagory);
        void update(PageCatagory pageCatagory);
        void delete(PageCatagory pageCatagory);
        PageCatagory getById(long PageCatagoryId);
        IQueryable<PageCatagory> getQueryable();
    }
}
