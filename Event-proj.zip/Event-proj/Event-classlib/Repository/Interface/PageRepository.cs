﻿using Event_classlib.Entity;
using System.Linq;

namespace Event_classlib.Repository.Interface
{
    public interface PageRepository
    {
        void insert(Page page);
        void update(Page page);
        void delete(Page page);
        Page getById(long PageId);
        IQueryable<Page> getQueryable();
    }
}
