﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Event_classlib.Service.Implementation
{
    public class EventServiceImpl : EventService
    {
        private readonly EventRepository _eventRepository;
        private readonly EventAssembler _eventAssembler;
        public EventServiceImpl(EventRepository eventRepository, EventAssembler eventAssembler)
        {
            _eventRepository = eventRepository;
            _eventAssembler = eventAssembler;
        }
        public void delete(long EventId)
        {
            try
            {
                var notice = _eventRepository.getById(EventId);
                _eventRepository.delete(notice);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void save(EventDto eventDto)
        {
            try
            {
                using (TransactionScope tx = new TransactionScope(TransactionScopeOption.Required))
                {
                    Event events = new Event();
                    _eventAssembler.copy(events, eventDto);
                    _eventRepository.insert(events);
                    tx.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void update(EventDto eventDto)
        {
            try
            {
                Event events = _eventRepository.getById(eventDto.EventId);
                _eventAssembler.copy(events, eventDto);
                _eventRepository.update(events);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
