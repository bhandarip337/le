﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Event_classlib.Service.Implementation
{
    public class NoticeServiceImpl : NoticeService
    {
        private readonly NoticeRepository _noticeRepository;
        private readonly NoticeAssembler _noticeAssembler;
        public NoticeServiceImpl(NoticeRepository noticeRepository, NoticeAssembler noticeAssembler)
        {
            _noticeRepository = noticeRepository;
            _noticeAssembler = noticeAssembler;
        }
        public void delete(long NoticeId)
        {
            try
            { 
                var notice = _noticeRepository.getById(NoticeId);
                _noticeRepository.delete(notice);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void save(NoticeDto noticeDto)
        {
            try
            {
                using (TransactionScope tx = new TransactionScope(TransactionScopeOption.Required))
                {
                    Notice notice = new Notice();
                    _noticeAssembler.copy(notice, noticeDto);
                    _noticeRepository.insert(notice);
                    tx.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void update(NoticeDto noticeDto)
        {
            try
            {
                Notice notice = _noticeRepository.getById(noticeDto.NoticeId);
                _noticeAssembler.copy(notice, noticeDto);
                _noticeRepository.update(notice);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
