﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Event_classlib.Service.Implementation
{
    public class PageCatagoryServiceImpl : PageCatagoryService
    {
        private readonly PageCatagoryRepository _pageCatagoryRepository;
        private readonly PageCatagoryAssembler _pageCatagoryAssembler;
        public PageCatagoryServiceImpl(PageCatagoryRepository pageCatagoryRepository,PageCatagoryAssembler pageCatagoryAssembler)
        {
            _pageCatagoryRepository = pageCatagoryRepository;
            _pageCatagoryAssembler = pageCatagoryAssembler;
        }
        public void delete(long CatagoryId)
        {
            try
            {
                var pageCatagory = _pageCatagoryRepository.getById(CatagoryId);
                _pageCatagoryRepository.delete(pageCatagory);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void save(PageCatagoryDto pageCatagoryDto)
        {
            try
            {
                using (TransactionScope tx = new TransactionScope(TransactionScopeOption.Required))
                {
                    PageCatagory pageCatagory = new PageCatagory();
                    _pageCatagoryAssembler.copy(pageCatagory, pageCatagoryDto);
                    _pageCatagoryRepository.insert(pageCatagory);
                    tx.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void update(PageCatagoryDto pageCatagoryDto)
        {
            try
            {
                PageCatagory pageCatagory = _pageCatagoryRepository.getById(pageCatagoryDto.CatagoryId);
                _pageCatagoryAssembler.copy(pageCatagory, pageCatagoryDto);
                _pageCatagoryRepository.update(pageCatagory);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
