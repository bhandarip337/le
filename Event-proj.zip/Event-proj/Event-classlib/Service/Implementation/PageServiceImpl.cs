﻿using Event_classlib.Assembler.Interface;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Event_classlib.Service.Implementation
{
    public class PageServiceImpl : PageService
    {
        private readonly PageRepository _pageRepository;
        private readonly PageAssembler _pageAssembler;
        public PageServiceImpl(PageRepository pageRepository, PageAssembler pageAssembler)
        {
            _pageRepository = pageRepository;
            _pageAssembler = pageAssembler;
        }
        public void delete(long PageId)
        {
            try
            {
                var page = _pageRepository.getById(PageId);
                _pageRepository.delete(page);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void save(PageDto pageDto)
        {
            try
            {
                using (TransactionScope tx = new TransactionScope(TransactionScopeOption.Required))
                {
                    Page page = new Page();
                    _pageAssembler.copy(page, pageDto);
                    _pageRepository.insert(page);
                    tx.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void update(PageDto pageDto)
        {
            try
            {
                Page page = _pageRepository.getById(pageDto.PageId);
                _pageAssembler.copy(page, pageDto);
                _pageRepository.update(page);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
