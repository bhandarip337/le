﻿using Event_classlib.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Service.Interface
{
    public interface NoticeService
    {
        void save(NoticeDto noticeDto);
        void update(NoticeDto noticeDto);
        void delete(long NoticeId);
    }
}