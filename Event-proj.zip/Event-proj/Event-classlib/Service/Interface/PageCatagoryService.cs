﻿using Event_classlib.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Service.Interface
{
    public interface PageCatagoryService
    {
        void save(PageCatagoryDto pageCatagoryDto);
        void update(PageCatagoryDto pageCatagoryDto);
        void delete(long CatagoryId);
    }
}
