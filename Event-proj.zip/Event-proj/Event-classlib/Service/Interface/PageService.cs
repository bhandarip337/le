﻿using Event_classlib.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace Event_classlib.Service.Interface
{
    public interface PageService
    {
        void save(PageDto pageDto);
        void update(PageDto pageDto);
        void delete(long PageId);
    }
}
