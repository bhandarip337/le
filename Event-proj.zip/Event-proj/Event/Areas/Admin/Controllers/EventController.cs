﻿using AutoMapper;
using Event.FilterModel;
using Event_classlib.Dto;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;

namespace Event.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class EventController : Controller
    {
        private readonly EventRepository _eventRepository;
        private readonly EventService _eventService;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public EventController(IMapper mapper, EventRepository eventRepository, EventService eventService, IWebHostEnvironment webHostEnvironment)
        {
            _mapper = mapper;
            _eventRepository = eventRepository;
            _eventService = eventService;
            _webHostEnvironment = webHostEnvironment;
        }
        //---------------------[Index]-----------------------
        public IActionResult Index(EventFilter filter)
        {
            var Event = _eventRepository.getQueryable().Where(a => a.EventId >= 0).ToList();
            if (!String.IsNullOrWhiteSpace(filter.EventSearchKey))
            {
                Event = Event.Where(
                a => a.EventTitle.Contains(filter.EventSearchKey, StringComparison.OrdinalIgnoreCase)
                || a.EventDescription.Contains(filter.EventSearchKey, StringComparison.OrdinalIgnoreCase)
                || a.EventTime.ToString("hh:mm").Contains(filter.EventSearchKey)
                || a.EventEndTime.ToString("hh:mm").Contains(filter.EventSearchKey)
                || a.EventDate.ToString("dd/mm/yyyy").Contains(filter.EventSearchKey)
                || a.EventEndDate.ToString("dd/mm/yyyy").Contains(filter.EventSearchKey)
                || a.EventVenue.Contains(filter.EventSearchKey, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            return View(Event);
        }
        //---------------------------------------------------
        //---------------------[Add]-------------------------
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Add(EventDto eventDto,IFormFile file)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (file != null)
                    {
                        String Folder = "pic/event/";
                        String UniueName = Guid.NewGuid().ToString()+file.FileName;
                        eventDto.EventImg = UniueName;
                        Folder += UniueName;
                        String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                        file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                    }
                    _eventService.save(eventDto);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("Index");
        }
        //----------------------------------------------------
        //---------------------[Edit]-------------------------
        [HttpGet]
        public IActionResult Edit(long Id)
        {
            try
            {
                var eventDetail = _eventRepository.getById(Id);
                var events = EventDetails(eventDetail);
                return View(events);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Edit(EventDto eventDto, IFormFile file)
        {
            try
            {
                if (file != null)
                {
                    String Folder = "pic/event/";
                    String UniueName = Guid.NewGuid().ToString() + file.FileName;
                    eventDto.EventImg = UniueName;
                    Folder += UniueName;
                    String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                    file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                }
                _eventService.update(eventDto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        //---------------------[Delete]-----------------------
        [HttpGet]
        public IActionResult Delete(long Id)
        {
            try
            {
                _eventService.delete(Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        private object EventDetails(Event_classlib.Entity.Event eventDetail)
        {
            var details = _mapper.Map<EventDto>(eventDetail);
            return details;
        }
        //private object IndexNoticeDetails(global::Event.ViewModel.NoticeIndexViewModel indexnoticeDetail)
        //{
        //    var details = _mapper.Map<NoticeIndexViewModel>(indexnoticeDetail);
        //    return details;
        //}
    }
}
