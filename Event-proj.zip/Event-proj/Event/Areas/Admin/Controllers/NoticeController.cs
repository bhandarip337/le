﻿using AutoMapper;
using Event.FilterModel;
using Event.Models;
using Event.ViewModel;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Event.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class NoticeController : Controller
    {
        private readonly NoticeRepository _noticeRepository;
        private readonly NoticeService _noticeService;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public NoticeController(IMapper mapper, NoticeRepository noticeRepository, NoticeService noticeService, IWebHostEnvironment webHostEnvironment)
        {
            _mapper = mapper;
            _noticeRepository = noticeRepository;
            _noticeService = noticeService;
            _webHostEnvironment = webHostEnvironment;
        }
        //---------------------[Index]-----------------------
        public IActionResult Index(NoticeFilter filter)
        {
            var Notice = _noticeRepository.getQueryable().Where(a => a.NoticeId >= 0).ToList();
            if (!String.IsNullOrWhiteSpace(filter.NoticeSearchKey))
            {
                Notice = Notice.Where(a => a.NoticeTitle.Contains(filter.NoticeSearchKey, StringComparison.OrdinalIgnoreCase) 
                || a.NoticeDescription.Contains(filter.NoticeSearchKey, StringComparison.OrdinalIgnoreCase)
                || a.NoticeDate.ToString("dd/mm/yyyy").Contains(filter.NoticeSearchKey)
                || a.NoticeEndDate.ToString("dd/mm/yyyy").Contains(filter.NoticeSearchKey)).ToList();
            }
            return View(Notice);
        }
        //---------------------------------------------------
        //---------------------[Add]-------------------------
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Add(NoticeDto noticeDto, IFormFile file)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (file != null)
                    {
                        String Folder = "pic/notice/";
                        String UniueName = Guid.NewGuid().ToString() + file.FileName;
                        noticeDto.NoticeImg = UniueName;
                        Folder += UniueName;
                        String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                        file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                    }
                    _noticeService.save(noticeDto);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("Index");
        }
        //----------------------------------------------------
        //---------------------[Edit]-------------------------
        [HttpGet]
        public IActionResult Edit(long Id)
        {
            try
            {
                var noticeDetail = _noticeRepository.getById(Id);
                var notice = NoticeDetails(noticeDetail);
                return View(notice);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Edit(NoticeDto noticeDto, IFormFile file)
        {
            try
            {
                if (file != null)
                {
                    String Folder = "pic/notice/";
                    String UniueName = Guid.NewGuid().ToString() + file.FileName;
                    noticeDto.NoticeImg = UniueName;
                    Folder += UniueName;
                    String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                    file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                }
                _noticeService.update(noticeDto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        //---------------------[Delete]-----------------------
        [HttpGet]
        public IActionResult Delete(long Id)
        {
            try
            {
                _noticeService.delete(Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //------------------------------------------------------
        private object NoticeDetails(Notice noticeDetail)
        {
            var details = _mapper.Map<NoticeDto>(noticeDetail);
            return details;
        }
        //private object IndexNoticeDetails(global::Event.ViewModel.NoticeIndexViewModel indexnoticeDetail)
        //{
        //    var details = _mapper.Map<NoticeIndexViewModel>(indexnoticeDetail);
        //    return details;
        //}
    }
}
