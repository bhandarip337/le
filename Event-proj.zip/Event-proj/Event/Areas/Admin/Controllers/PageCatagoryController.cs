﻿using AutoMapper;
using Event.FilterModel;
using Event_classlib.Dto;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace Event.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PageCatagoryController : Controller
    {
        private readonly PageCatagoryRepository _pageCatagoryRepository;
        private readonly PageCatagoryService _pageCatagoryService;
        private readonly IMapper _mapper;
        public PageCatagoryController(IMapper mapper, PageCatagoryRepository pageCatagoryRepository, PageCatagoryService pageCatagoryService)
        {
            _mapper = mapper;
            _pageCatagoryRepository = pageCatagoryRepository;
            _pageCatagoryService = pageCatagoryService;
        }
        //---------------------[Index]-----------------------
        public IActionResult Index(PageCatagoryFilter filter)
        {
            var PageCatagory = _pageCatagoryRepository.getQueryable().Where(a => a.CatagoryId >= 0).ToList();
            if (!String.IsNullOrWhiteSpace(filter.PageCatagorySearchKey))
            {
                PageCatagory = PageCatagory.Where(a => a.CatagoryName.Contains(filter.PageCatagorySearchKey, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            return View(PageCatagory);
        }
        //---------------------------------------------------
        //---------------------[Add]-------------------------
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Add(PageCatagoryDto pageCatagoryDto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _pageCatagoryService.save(pageCatagoryDto);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("Index");
        }
        //----------------------------------------------------
        //---------------------[Edit]-------------------------
        [HttpGet]
        public IActionResult Edit(long Id)
        {
            try
            {
                var pageCatagoryDetail = _pageCatagoryRepository.getById(Id);
                var pageCatagory = PageCatagoryDetails(pageCatagoryDetail);
                return View(pageCatagory);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Edit(PageCatagoryDto pageCatgoryDto)
        {
            try
            {
                _pageCatagoryService.update(pageCatgoryDto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        //---------------------[Delete]-----------------------
        [HttpGet]
        public IActionResult Delete(long Id)
        {
            try
            {
                _pageCatagoryService.delete(Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        private object PageCatagoryDetails(Event_classlib.Entity.PageCatagory pageCatagoryDetail)
        {
            var details = _mapper.Map<PageCatagoryDto>(pageCatagoryDetail);
            return details;
        }
    }
}
