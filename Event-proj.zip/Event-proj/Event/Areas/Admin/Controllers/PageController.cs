﻿using AutoMapper;
using Event.FilterModel;
using Event_classlib.Dto;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.IO;
using System.Linq;

namespace Event.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PageController : Controller
    {
        private readonly PageRepository _pageRepository;
        private readonly PageCatagoryRepository _pageCatagoryRepository;
        private readonly PageService _pageService;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public PageController(IMapper mapper, PageRepository pageRepository, PageService pageService, PageCatagoryRepository pageCatagoryRepository,IWebHostEnvironment webHostEnvironment)
        {
            _mapper = mapper;
            _pageRepository = pageRepository;
            _pageCatagoryRepository = pageCatagoryRepository;
            _pageService = pageService;
            _webHostEnvironment = webHostEnvironment;
        }
        //---------------------[Index]-----------------------
        public IActionResult Index(PageFilter filter)
        {
            var Page = _pageRepository.getQueryable().Where(a => a.PageId >= 0).ToList();
            if (!String.IsNullOrWhiteSpace(filter.PageSearchKey))
            {
                Page = Page.Where(a => a.PageTitle.Contains(filter.PageSearchKey, StringComparison.OrdinalIgnoreCase)
                || a.PageCatagory.Contains(filter.PageSearchKey, StringComparison.OrdinalIgnoreCase)
                || a.PageDescription.Contains(filter.PageSearchKey, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            return View(Page);
        }
        //---------------------------------------------------
        //---------------------[Add]-------------------------
        [HttpGet]
        public IActionResult Add()
        {
            var Catagory =_pageCatagoryRepository.getQueryable().Where(a => a.CatagoryStatus == true).ToList();
            ViewBag.Catagory = new SelectList(Catagory, "CatagoryName", "CatagoryName");
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Add(PageDto pageDto,IFormFile file)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (file != null)
                    {
                        String Folder = "pic/page/";
                        String UniueName = Guid.NewGuid().ToString() + file.FileName;
                        pageDto.PageImg = UniueName;
                        Folder += UniueName;
                        String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                        file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                    }
                    _pageService.save(pageDto);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("Index");
        }
        //----------------------------------------------------
        //---------------------[Edit]-------------------------
        [HttpGet]
        public IActionResult Edit(long Id)
        {
            try
            {
                var pageDetail = _pageRepository.getById(Id);
                var page = PageDetails(pageDetail);
                var Catagory = _pageCatagoryRepository.getQueryable().Where(a => a.CatagoryStatus == true).ToList();
                ViewBag.Catagory = new SelectList(Catagory, "CatagoryName", "CatagoryName");
                return View(page);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Edit(PageDto pageDto, IFormFile file)
        {
            try
            {
                if (file != null)
                {
                    String Folder = "pic/page/";
                    String UniueName = Guid.NewGuid().ToString() + file.FileName;
                    pageDto.PageImg = UniueName;
                    Folder += UniueName;
                    String ServerFolder = Path.Combine(_webHostEnvironment.WebRootPath, Folder);
                    file.CopyToAsync(new FileStream(ServerFolder, FileMode.Create));
                }
                _pageService.update(pageDto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        //---------------------[Delete]-----------------------
        [HttpGet]
        public IActionResult Delete(long Id)
        {
            try
            {
                _pageService.delete(Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //----------------------------------------------------
        private object PageDetails(Event_classlib.Entity.Page pageDetail)
        {
            var details = _mapper.Map<PageDto>(pageDetail);
            return details;
        }
    }
}
