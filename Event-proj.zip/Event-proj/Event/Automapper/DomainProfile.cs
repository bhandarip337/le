﻿using AutoMapper;
using Event_classlib.Entity;
using Event_classlib.Dto;

namespace Event.Automapper
{
    public class DomainProfile : Profile
    {
        public DomainProfile()
        {
            //Map Here
            CreateMap<PageCatagoryDto, PageCatagory>().ReverseMap();
            CreateMap<PageDto, Page>().ReverseMap();
            CreateMap<NoticeDto, Notice>().ReverseMap();
            CreateMap<EventDto, Event_classlib.Entity.Event>().ReverseMap();
        }
    }
}
