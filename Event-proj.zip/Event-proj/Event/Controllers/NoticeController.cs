﻿using AutoMapper;
using Event.Models;
using Event.ViewModel;
using Event_classlib.Dto;
using Event_classlib.Entity;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;

namespace Event.Controllers
{
    public class NoticeController : Controller
    {
        private readonly NoticeRepository _noticeRepository;
        private readonly NoticeService _noticeService;
        private readonly IMapper _mapper;
        public NoticeController(IMapper mapper, NoticeRepository noticeRepository, NoticeService noticeService)
        {
            _mapper = mapper;
            _noticeRepository = noticeRepository;
            _noticeService = noticeService;
        }
        //---------------------[Index]-----------------------
        public IActionResult Index()
        {
            var notice = _noticeRepository.getQueryable().Where(a => a.NoticeId >= 0).ToList();
            return View(notice);
        }
        //---------------------------------------------------
        private object NoticeDetails(Notice noticeDetail)
        {
            var details = _mapper.Map<NoticeDto>(noticeDetail);
            return details;
        }
        //private object IndexNoticeDetails(global::Event.ViewModel.NoticeIndexViewModel indexnoticeDetail)
        //{
        //    var details = _mapper.Map<NoticeIndexViewModel>(indexnoticeDetail);
        //    return details;
        //}
    }
}
