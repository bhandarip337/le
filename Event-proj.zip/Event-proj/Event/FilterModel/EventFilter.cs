﻿using Event.Models;

namespace Event.FilterModel
{
    public class EventFilter:PaginationFilter
    {
        public string EventSearchKey { get; set; }
    }
}
