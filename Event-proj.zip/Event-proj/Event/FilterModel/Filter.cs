﻿using Event.Models;

namespace Event.FilterModel
{
    public class Filter:PaginationFilter
    {
        public string SearchKey { get; set; }
    }
}
