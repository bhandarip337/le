﻿using Event.Models;

namespace Event.FilterModel
{
    public class NoticeFilter:PaginationFilter
    {
        public string NoticeSearchKey { get; set; }
    }
}
