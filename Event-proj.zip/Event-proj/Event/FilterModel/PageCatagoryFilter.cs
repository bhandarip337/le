﻿using Event.Models;

namespace Event.FilterModel
{
    public class PageCatagoryFilter:PaginationFilter
    {
        public string PageCatagorySearchKey { get; set; }
    }
}
