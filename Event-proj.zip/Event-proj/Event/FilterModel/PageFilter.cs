﻿using Event.Models;

namespace Event.FilterModel
{
    public class PageFilter:PaginationFilter
    {
        public string PageSearchKey { get; set; }
    }
}
