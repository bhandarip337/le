﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;
namespace Event.Models
{
    public class EventModel
    {
        public long EventId { get; set; }
        [Required]
        [Display(Name = "Event Title")]
        public string EventTitle { get; set; }
        [Required]
        [Display(Name = "Event Description")]
        public string EventDescription { get; set; }
        [Required]
        [Display(Name = "Event Time")]
        public DateTime EventTime { get; set; }
        [Required]
        [Display(Name = "Event End Time")]
        public DateTime EventEndTime { get; set; }
        [Required]
        [Display(Name = "Event Date")]
        public DateTime EventDate { get; set; }
        [Required]
        [Display(Name = "Event End Date")]
        public DateTime EventEndDate { get; set; }
        [Required]
        [Display(Name = "Event Venue")]
        public string EventVenue { get; set; }
        [Required]
        [Display(Name = "Event Image")]
        public string EventImg { get; set; }
        public bool EventStatus { get; set; } = true;
    }
}
