﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Event.Models
{
    public class NoticeModel
    {
        public long NoticeId { get; set; }
        [Required]
        [Display(Name = "Notice Title")]
        public string NoticeTitle { get; set; }
        [Required]
        [Display(Name = "Notice Description")]
        public string NoticeDescription { get; set; }
        [Required]
        [Display(Name = "Notice Date")]
        public DateTime NoticeDate { get; set; }
        [Required]
        [Display(Name = "Notice End Date")]
        public DateTime NoticeEndDate { get; set; }
        [Required]
        [Display(Name = "Notice Image")]
        public string NoticeImg { get; set; }
        public bool NoticeStatus { get; set; } = true;
    }
}
