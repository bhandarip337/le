﻿using System.ComponentModel.DataAnnotations;

namespace Event.Models
{
    public class PageCatagoryModel
    {
        public long CatagoryId { get; set; }
        [Required]
        [Display(Name = "Page Catagory Name")]
        public string CatagoryName { get; set; }
        public bool CatagoryStatus { get; set; } = true;
    }
}
