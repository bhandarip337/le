﻿using Event_classlib.Entity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Event.Models
{
    public class PageModel
    {
        public long PageId { get; set; }
        [Required]
        [Display(Name = "Page Title")]
        public string PageTitle { get; set; }
        [Required]
        [Display(Name = "Page Catagory")]
        public string PageCatagory { get; set; }
        [Required]
        [Display(Name = "Page Discription")]
        public string PageDescription { get; set; }
        [Required]
        [Display(Name = "Page Image")]
        public string PageImg { get; set; }
        public bool PageStatus { get; set; } = true;
        public virtual PageCatagory Catagory { get; set; }
    }

}
