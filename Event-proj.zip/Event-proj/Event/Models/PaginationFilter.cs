﻿namespace Event.Models
{
    public class PaginationFilter
    {
        public int page { get; set; } = 1;
        public int number_of_rows { get; set; } = 20;
    }
}
