using Event_classlib.Assembler.Implementation;
using Event_classlib.Assembler.Interface;
using Event_classlib.Data;
using Event_classlib.Helper;
using Event_classlib.Repository.Implementations;
using Event_classlib.Repository.Interface;
using Event_classlib.Service.Implementation;
using Event_classlib.Service.Interface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using SharpDX.DXGI;

namespace Event
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //-----------------------------------------------------[Prashant]----------------------------------------------------------

            services.AddDbContext<AppDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            //-------------------------------------------------------------------------------------------------------------------------
            services.AddControllersWithViews();
            //----------------[Prashant]----------------------
            services.AddAutoMapper(typeof(Startup).Assembly);
            services.AddControllersWithViews();
            services.AddRazorPages();
            registerElements(services);
            registerHelpers(services);
            registerRepository(services);
            registerAssembler(services);
            registerServices(services);
            services.AddMvc()
             .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
             .AddDataAnnotationsLocalization(options => options.DataAnnotationLocalizerProvider = (t, f) => f.Create(typeof(SharedResource)));
            services.AddResponseCaching();
            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.MimeTypes = new[] { "text/plain",
                "text/css",
                "application/javascript",
                "text/html",
                "application/xml",
                "text/xml",
                "application/json",
                "text/json", };
            });
            //------------------------------------------------
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //----------------------
                app.UseStatusCodePages();
                //----------------------
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseAuthorization();
            //------------------------------
            var options = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();
            app.UseRequestLocalization(options.Value);
            //------------------------------

            app.UseEndpoints(endpoints =>
            {
                //endpoints.MapControllerRoute(
                //   name: "default",
                //   pattern: "{controller=Home}/{action=Index}/{id?}");
                //endpoints.MapControllerRoute(
                //    name: "admin",
                //   pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");
                //----------------[Prashant]--------------------
                endpoints.MapRazorPages();
                endpoints.MapControllerRoute("areas", "{area:exists}/{controller=Home}/{action=Index}/{id?}");
                endpoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
                //----------------------------------------------
            });
            //-------------------------------
            app.UseCors(options => options.AllowAnyOrigin());
            //-------------------------------
        }
        //----------------------------------[Prashant]-----------------------------------------
        private void registerElements(IServiceCollection services)
        {
            registerServices(services);
            registerAssembler(services);
            registerRepository(services);
            registerHelpers(services);
        }
        private void registerHelpers(IServiceCollection services)
        {
            services.AddScoped<HtmlEncodingClassHelper, HtmlEncodingClassHelperImpl>();
            services.AddScoped(typeof(DetailsEncoder<>), typeof(DetailsEncoderImpl<>));

        }
        private void registerRepository(IServiceCollection services)
        {
            //Register Here
            services.AddScoped<PageCatagoryRepository, PageCatagoryRepositoryImpl>();
            services.AddScoped<PageRepository, PageRepositoryImpl>();
            services.AddScoped<NoticeRepository, NoticeRepositoryImpl>();
            services.AddScoped<EventRepository, EventRepositoryImpl>();
        }
        private void registerAssembler(IServiceCollection services)
        {
            //Register Here
            services.AddScoped<PageCatagoryAssembler, PageCatagoryAssemblerImpl>();
            services.AddScoped<PageAssembler, PageAssemblerImpl>();
            services.AddScoped<NoticeAssembler, NoticeAssemblerImpl>();
            services.AddScoped<EventAssembler, EventAssemblerImpl>();
        }
        private void registerServices(IServiceCollection services)
        {
            //Register Here
            services.AddScoped<PageCatagoryService, PageCatagoryServiceImpl>();
            services.AddScoped<PageService, PageServiceImpl>();
            services.AddScoped<NoticeService, NoticeServiceImpl>();
            services.AddScoped<EventService, EventServiceImpl>();
        }
        //-------------------------------------------------------------------------------------
    }
}
