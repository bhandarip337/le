﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Event.ViewModel
{
    public class NoticeIndexViewModel
    {
        public int NoticeId { get; set; }
        public string NoticeTitle { get; set; }
        public string NoticeDescription { get; set; }
        public DateTime NoticeDate { get; set; }
        public DateTime NoticeEndDate { get; set; }
        public string NoticeImg { get; set; }
        public bool NoticeIsEnabled { get; set; } = true;
    }
}
