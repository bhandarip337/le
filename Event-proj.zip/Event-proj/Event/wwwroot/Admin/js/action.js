﻿function del(area,controller, id) {
    let d = confirm("Are you sure you want to delete");
    if (d == true) {
        window.location.replace("/"+area+"/" + controller + "/delete/" + id);
    }
}